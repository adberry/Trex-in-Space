﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleButtons : MonoBehaviour {
	/*
    public Button button;

<<<<<<< HEAD
    public void LoadLevel(string name)
    {
    SceneManager.LoadScene("mars", LoadSceneMode.Additive);
    }

=======
   

    public void LoadLevel(string name)
    {
        SceneManager.LoadScene(name);
    }

>>>>>>> refs/remotes/origin/Adam-branch
    public void QuitRequest()
    {
        Application.Quit();
    }
<<<<<<< HEAD
    */
}
